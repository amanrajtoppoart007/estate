<?php
namespace App\Library;
class TenancyContract
{
     public function __construct()
    {

    }

    private function create($tenant_id,$params)
    {

    }

    private function renew($contract_id,$params)
    {

    }

    private function edit($contract_id,$params)
    {

    }
}
