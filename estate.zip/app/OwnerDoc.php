<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OwnerDoc extends Model
{
    protected $guarded = [];
}
