<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReceiptData extends Model
{
    //
}
