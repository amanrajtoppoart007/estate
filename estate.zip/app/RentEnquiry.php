<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RentEnquiry extends Model
{
    protected $guarded = [];
}
