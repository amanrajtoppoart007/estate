<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CoaCategory extends Model
{
    protected $guarded    = [];
}
