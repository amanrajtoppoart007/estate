<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaleEnquiry extends Model
{
    //
}
